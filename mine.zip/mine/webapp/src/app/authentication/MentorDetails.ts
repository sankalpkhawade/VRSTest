export interface MentorDetails {
    userName: String,
    firstName: String,
    lastName: String,
    email: String,
    password: String,
    contact: String,
    linkedInUrl: String,
    experience: number,
    active: String
}