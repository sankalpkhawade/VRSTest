export interface MentorSkills {
    skillName: String,
    trainings: number,
    facilities: String,
    experience: number,
    rating: number
}