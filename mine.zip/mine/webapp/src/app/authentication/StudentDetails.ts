export interface StudentDetails {
    userName: String,
    firstName: String,
    lastName: String,
    email: String,
    password: String,
    contact: String,
    active: String
}